"""
Web-based trading dashboard (simulation only).

This Flask application serves a simple dashboard that displays
mock market data, renders an interactive price chart using Chart.js,
and demonstrates responsive design for mobile use. The app is
designed as an educational prototype; it does **not** place or
facilitate real trades. Use this project for learning purposes
only.

To run the application:

1. Install dependencies: pip install flask
2. In this folder, run: python app.py
3. Navigate to http://localhost:5000 in your browser.

The app also exposes a small API endpoint `/api/data` that returns
mock price data for demonstration.
"""

from datetime import datetime, timedelta
import random
from flask import Flask, jsonify, render_template


app = Flask(__name__)


def generate_mock_price_data(days: int = 60):
    """Generate mock price data for the last `days` days.

    Returns a list of dictionaries with date and closing price keys.
    The price is simulated via a random walk starting from 100.
    """
    prices = []
    price = 100.0
    for i in range(days):
        # Simulate daily change between -2% and +2%
        change_percent = random.uniform(-0.02, 0.02)
        price *= (1 + change_percent)
        date = datetime.now() - timedelta(days=days - i)
        prices.append({
            "date": date.strftime("%Y-%m-%d"),
            "close": round(price, 2)
        })
    return prices


@app.route("/")
def index():
    """Render the main dashboard page."""
    return render_template("index.html")


@app.route("/api/data")
def api_data():
    """Return mock price data as JSON."""
    data = generate_mock_price_data()
    return jsonify(data)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")