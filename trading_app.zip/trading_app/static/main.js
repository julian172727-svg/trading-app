/*
 * main.js
 *
 * Dieses Script holt Kursdaten über die API und zeichnet den
 * Kursverlauf in ein Chart. Es sorgt dafür, dass die
 * Darstellung responsiv bleibt und der Nutzer die Daten mit
 * einem Knopfdruck aktualisieren kann.
 */

let chartInstance = null;

/**
 * Generate mock price data for the past N days. Uses a simple random
 * walk to simulate daily price changes between -2% and +2%.
 * @param {number} days Number of days to simulate
 * @returns {Array<{date: string, close: number}>}
 */
function generateMockData(days = 60) {
  const data = [];
  let price = 100;
  for (let i = 0; i < days; i++) {
    const changePercent = (Math.random() - 0.5) * 0.04; // ±2%
    price *= 1 + changePercent;
    const date = new Date();
    date.setDate(date.getDate() - (days - i));
    data.push({
      date: date.toISOString().slice(0, 10),
      close: parseFloat(price.toFixed(2)),
    });
  }
  return data;
}

function formatChartData(data) {
  return {
    labels: data.map((d) => d.date),
    datasets: [
      {
        label: 'Preis',
        data: data.map((d) => d.close),
        borderColor: '#3e92cc',
        backgroundColor: 'rgba(62, 146, 204, 0.2)',
        fill: true,
        tension: 0.2,
      },
    ],
  };
}

function renderChart() {
  const data = generateMockData();
  const ctx = document.getElementById('priceChart').getContext('2d');
  const config = {
    type: 'line',
    data: formatChartData(data),
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          ticks: {
            maxTicksLimit: 5,
            autoSkip: true,
          },
        },
        y: {
          beginAtZero: false,
        },
      },
    },
  };
  if (chartInstance) {
    chartInstance.destroy();
  }
  chartInstance = new Chart(ctx, config);
}

// Refresh button functionality
document.getElementById('refreshBtn').addEventListener('click', () => {
  renderChart();
});

// Initial rendering after DOM has loaded
document.addEventListener('DOMContentLoaded', () => {
  renderChart();
});